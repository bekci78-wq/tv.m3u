<h1>Bulgaria</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | BNT1 | [x]() | <img height="20" src="https://i.imgur.com/7JU9b5j.png"/> | BNT1.bg |
| 2   | bTV | [x]() | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ae/BTV_Bulgaria_logo.svg/320px-BTV_Bulgaria_logo.svg.png"/> | bTV.bg |
| 3   | Nova TV | [x]() | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f8/NOVA_logo.svg/167px-NOVA_logo.svg.png"/> | NovaTV.bg |
| 5   | Bulgaria On Air | [x]() | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/6/61/Bulgariaonair.png"/> | BulgariaOnAir.bg |
| 7   | BNT2 | [x]() | <img height="20" src="https://i.imgur.com/FyTUr9Q.png"/> | BNT2.bg |
| 64  | BNT3 | [x]() | <img height="20" src="https://i.imgur.com/pPpSJ4u.png"/> | BNT3.bg |
| 0   | Nova News | [x]() | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/f/fc/Nova_News_Bulgaria_logo.png"/> | NovaNews.bg |
| 8   | City TV Ⓢ | [>](https://tv.city.bg/play/tshls/citytv/index.m3u8) | <img height="20" src="https://i.imgur.com/BjRTbrU.png"/> | City.bg |


<h2>DVB-S</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | BNT4 | [x]() | <img height="20" src="https://i.imgur.com/Lw8b3yu.png"/> | BNT4.bg |
| 0   | Euronews Bulgaria Ⓨ | [>](https://www.youtube.com/channel/UCU1i6qBMjY9El6q5L2OK8hA/live) | <img height="20" src="https://i.imgur.com/RrQVoOg.png"/> | EuroNewsBulgaria.bg |
| 0   | TV1 | [>](https://tv1.cloudcdn.bg/temp/livestream.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/6/64/Tv1-new.png"/> | TV1.bg |
