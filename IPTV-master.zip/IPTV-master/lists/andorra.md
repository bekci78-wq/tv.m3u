<h1>Andorra</h1>

| #    | Channel        | Link  | Logo | EPG id |
|:----:|:--------------:|:-----:|:----:|:------:|
| 1 | Andorra TV  | [>](https://videos.rtva.ad/live/rtva/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/3/32/Logo_Andorra_Televisi%C3%B3.png"/> | AndorraTV.ad |
