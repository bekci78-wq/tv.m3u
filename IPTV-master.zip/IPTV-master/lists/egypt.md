<h1>Egypt</h1>

| #  | Channel        | Link  | Logo | EPG id |
|:--:|:--------------:|:-----:|:----:|:------:|
| 1  | Aghapy TV | [>](https://5b622f07944df.streamlock.net/aghapy.tv/aghapy.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/en/e/eb/AghapyTV.jpg"/> | AghapyTV.eg |
| 2  | Al Ghad Plus | [>](https://playlist.fasttvcdn.com/pl/ykvm3f2fhokwxqsurp9xcg/alghad-plus/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/0/06/AlGhad_TV.png"/> | AlGhadPlus.eg |
| 3  | Al Ghad TV | [>](https://eazyvwqssi.erbvr.com/alghadtv/alghadtv.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/0/06/AlGhad_TV.png"/> | AlGhadTV.eg |
| 4  | Al Qahera News | [>](https://bcovlive-a.akamaihd.net/d30cbb3350af4cb7a6e05b9eb1bfd850/eu-west-1/6057955906001/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/ar/b/b0/%D9%82%D9%86%D8%A7%D8%A9_%D8%A7%D9%84%D9%82%D8%A7%D9%87%D8%B1%D8%A9_%D8%A7%D9%84%D8%A5%D8%AE%D8%A8%D8%A7%D8%B1%D9%8A%D8%A9.png"/> | AlQaheraNews.eg |
| 5  | Alhayat TV | [>](https://cdn3.wowza.com/5/OE5HREpIcEkySlNT/alhayat-live/ngrp:livestream_all/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/8/8c/Al-Hayat_Media_Center_Logo_%28variant_2%29.svg"/> | AlhayatTV.eg |
| 6  | Coptic TV | [>](https://5aafcc5de91f1.streamlock.net/ctvchannel.tv/ctv.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/en/4/4c/Coptic_news.jpg"/> | CopticTV.eg |
| 7  | Huda TV | [>](https://cdn.bestream.io:19360/elfaro1/elfaro1.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/5/58/Logo_huda_%D8%AD%D8%AC%D9%85_%D9%83%D8%A8%D9%8A%D8%B1.gif"/> | HudaTV.eg |
| 8  | Koogi TV | [>](https://5d658d7e9f562.streamlock.net/koogi.tv/koogi.smil/playlist.m3u8) | <img height="20" src=""/> | KoogiTV.eg |
| 9  | MBC Masr 1 | [>](https://mbc1-enc.edgenextcdn.net/out/v1/d5036cabf11e45bf9d0db410ca135c18/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/7/7c/MBC_Masr_Logo.png"/> | MBCMasr1.eg |
| 10  | MBC Masr 2 | [>](https://shls-masr2-ak.akamaized.net/out/v1/f683685242b549f48ea8a5171e3e993a/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/5/53/MBC_Masr_2_Logo.svg"/> | MBCMasr2.eg |
| 11  | Rotana Cinema | [>](https://rotana.hibridcdn.net/rotana/cinemamasr_net-7Y83PP5adWixDF93/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/9/92/Rotana_Cinema_Egy.png"/> | RotanaCinema.eg |
| 12  | Watan TV | [>](https://rp.tactivemedia.com/watantv_source/live/playlist.m3u8) | <img height="20" src=""/> | WatanTV.eg |