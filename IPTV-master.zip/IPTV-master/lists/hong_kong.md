<h1>Hong Kong</h1>

* https://en.wikipedia.org/wiki/List_of_television_stations_in_Hong_Kong#Free-to-air_television_channels

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 31  | RTHK TV 31 | [>](https://rthktv31-live.akamaized.net/hls/live/2036818/RTHKTV31/master.m3u8) | <img height="20" src="https://i.imgur.com/kf818kM.png"/> | RTHKTV31.hk |
| 32  | RTHK TV 32 | [>](https://rthktv32-live.akamaized.net/hls/live/2036819/RTHKTV32/master.m3u8) | <img height="20" src="https://i.imgur.com/MXLuUoU.png"/> | RTHKTV32.hk |
| 77  | HOY TV Ⓖ | [>](https://hoytv-live-stream.hoy.tv/ch78/index-fhd.m3u8) | <img height="20" src="https://i.imgur.com/NfVZPTT.png"/> | HKIBC.hk |
| 83  | TVB News Channel | [>](https://tvp22.sky4k.top/index1.php) | <img height="20" src="https://i.imgur.com/Gwij0Fj.png"/> | TVBNewsChannel.hk |
| 84  | TVB Finance (Sports & Information Channel) | [>](https://tvp22.sky4k.top/index2.php) | <img height="20" src="https://i.imgur.com/Fkkp7x7.png"/> | TVBFinanceSportsInformationChannel.hk |
