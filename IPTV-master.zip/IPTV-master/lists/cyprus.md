<h1>Cyprus</h1>

<h2>Republic of Cyprus</h2>

| #   | Channel           | Link  | Logo | EPG id |
|:---:|:-----------------:|:-----:|:----:|:------:|
| 1   | RIK 1 Ⓢ | [>](http://l6.cloudskep.com/tvb6/rik1-1/mpeg.2ts) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/Logo_RIK_1_2017.svg/640px-Logo_RIK_1_2017.svg.png"/> | RIK1.cy |
| 2   | RIK 2 Ⓢ | [>](http://l6.cloudskep.com/tvb6/rik2-1/mpeg.2ts) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Logo_RIK_2_2017.svg/640px-Logo_RIK_2_2017.svg.png"/> | RIK2.cy |
| 3   | RIK HD | [>](http://l6.cloudskep.com/tvb6/rikhd1/mpeg.2ts) | <img height="20" src="https://upload.wikimedia.org/wikipedia/el/7/7d/RIKHD2.png"/> | RIKHD.cy |
| 4   | RIK Sat | [>](https://l3.cloudskep.com/cybcsat/abr/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/Logo_RIK_Sat_2017.svg/640px-Logo_RIK_Sat_2017.svg.png"/> | RIKSat.cy |

<h2>Northern Cyprus</h2>

| #   | Channel           | Link  | Logo | EPG id |
|:---:|:-----------------:|:-----:|:----:|:------:|
| 1   | BRT 1 | [>](https://sc-kuzeykibrissmarttv.ercdn.net/brt1hd/bant1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/gOPAi2c.png"/> | BRT1.cy |
| 2   | BRT 2 | [>](https://sc-kuzeykibrissmarttv.ercdn.net/brt2hd/bant1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/t5kbIuj.png"/> | BRT2.cy |
| 3   | Ada TV Ⓢ | [>](https://sc-kuzeykibrissmarttv.ercdn.net/adatv/bant1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/LPQfdz2.png"/> | AdaTV.cy |
| 4   | Kıbrıs Genç TV Ⓢ | [>](https://sc-kuzeykibrissmarttv.ercdn.net/kibrisgenctv/bant1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/eBdQn9h.png"/> | KibrisGencTV.cy |
| 5   | Kanal T Ⓢ | [>](https://sc-kuzeykibrissmarttv.ercdn.net/kanalt/bantp1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/4bA4pXT.png"/> | KibrisKanalT.cy |
| 6   | Kıbrıs TV Ⓢ | [>](https://sc-kuzeykibrissmarttv.ercdn.net/kibristv/bant1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/5MJZPTo.png"/> | KibrisTV.cy |
| 7   | TV 2020 Ⓢ | [>](https://sc-kuzeykibrissmarttv.ercdn.net/tv2020/bantp1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/rtfsNdd.png"/> | TV2020.cy |
