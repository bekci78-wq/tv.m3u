<h1>Finland</h1>

* https://www.digita.fi/antennitv/vapaat-kanavat-ja-vastaanotto/hyodyllista-tietoa-tvsta/kanavajarjestys/

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Yle TV1 Ⓖ | [>](https://yletv.akamaized.net/hls/live/622365/yletv1fin/index.m3u8) | <img height="20" src="https://i.imgur.com/6yXZwUL.png"/> | YleTV1.fi |
| 2   | Yle TV2 Ⓖ | [>](https://yletv.akamaized.net/hls/live/622366/yletv2fin/index.m3u8) | <img height="20" src="https://i.imgur.com/4xkc6PL.png"/> | YleTV2.fi |
| 3   | MTV3 | [>](https://live-fi.tvkaista.net/mtv3/live.m3u8?src=freetv) | <img height="20" src="https://i.imgur.com/kNbmc8n.png"/> | MTV3.fi |
| 4   | Nelonen | [>](https://live-fi.tvkaista.net/nelonen/live.m3u8?src=freetv) | <img height="20" src="https://i.imgur.com/BFbCyfY.png"/> | Nelonen.fi |
| 5   | Yle Teema Fem Ⓖ | [>](https://yletv.akamaized.net/hls/live/622367/yletvteemafemfin/index.m3u8) | <img height="20" src="https://i.imgur.com/iDljufz.png"/> | YleTeemaFem.fi |
| 6   | MTV Sub | [>](https://live-fi.tvkaista.net/sub/live.m3u8?src=freetv) | <img height="20" src="https://i.imgur.com/VRCuxQt.png"/> | Sub.fi |
| 7   | TV5 Finland | [>](https://live-fi.tvkaista.net/tv5/live.m3u8?src=freetv) | <img height="20" src="https://i.imgur.com/MoukyGs.png"/> | TV5.fi |
| 8   | Liv | [>](https://live-fi.tvkaista.net/liv/live.m3u8?src=freetv) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/0/06/Liv_color_RGB.png"/> | Liv.fi |
| 9   | Jim | [>](https://live-fi.tvkaista.net/jim/live.m3u8?src=freetv) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/9/92/Jim_color_RGB.png"/> | Jim.fi |
| 10  | Kutonen | [>](https://live-fi.tvkaista.net/kutonen/live.m3u8?src=freetv) | <img height="20" src="https://i.imgur.com/4giVyxb.png"/> | Kutonen.fi |
| 11  | TLC Finland | [>](https://live-fi.tvkaista.net/tlc/live.m3u8?src=freetv) | <img height="20" src="https://i.imgur.com/0d5hP3A.png"/> | TLCFinland.fi |
| 12  | Star Channel Finland | [>](https://live-fi.tvkaista.net/star-channel/live.m3u8?src=freetv) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/Star_Channel_2020.svg/640px-Star_Channel_2020.svg.png"/> | StarChannel.fi |
| 13  | MTV Ava | [>](https://live-fi.tvkaista.net/ava/live.m3u8?src=freetv) | <img height="20" src="https://i.imgur.com/rtyJVgB.png"/> | AVA.fi |
| 14  | Hero | [>](https://live-fi.tvkaista.net/hero/live.m3u8?src=freetv) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/b/bd/Hero_color_RGB.png"/> | Hero.fi |
| 15  | Frii | [>](https://live-fi.tvkaista.net/frii/live.m3u8?src=freetv) | <img height="20" src="https://i.imgur.com/ljKoG9I.png"/> | Frii.fi |
| 17  | Alfa Ⓢ | [>](https://irrtv2.digitacdn.net/live/ott/irrtv/playlist.m3u8?organizationId=229401409&suiteItemId=230439940) | <img height="20" src="https://upload.wikimedia.org/wikipedia/fi/9/93/IRR-TV-1.png"/> | IRRTV.fi |
| 18  | TapahtumaTV Eveo | [>](https://live-fi.tvkaista.net/tapahtumatv-eveo/live.m3u8?src=freetv) | <img height="20" src="https://i.imgur.com/sR8nA8w.png"/> | Eveo.fi |
| 20  | National Geographic Finland Ⓖ | [>](https://live-fi.tvkaista.net/national-geographic/live.m3u8?src=freetv) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Natgeologo.svg/512px-Natgeologo.svg.png"/> | NationalGeographicFinland.fi |
| 21  | Viaplay TV | [>](https://live-fi.tvkaista.net/viaplay-tv/live.m3u8?src=freetv) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/Viaplay_TV_logo.svg/640px-Viaplay_TV_logo.svg.png"/> | ViaplayTV.fi |
| 33  | OnniTV | [>](https://onnitv.digitacdn.net/live/ott/onnitv/playlist.m3u8?organizationId=83459409&suiteItemId=83459780) | <img height="20" src="https://i.imgur.com/HzILf2H.png"/> | KotiTV.fi |
| 45  | Taivas TV7 | [>](https://vod.tv7.fi/tv7-fi/_definst_/smil:tv7-fi.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/a4iNVXA.png"/> | TaivasTV7.fi |
| 46  | Himlen TV7 | [>](https://vod.tv7.fi/tv7-se/_definst_/smil:tv7-se.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/a4iNVXA.png"/> | HimlenTV7.fi |
| 99  | MTV Uutiset Live | [>](https://live.streaming.a2d.tv/asset/20025962.isml/.m3u8) | <img height="20" src="https://i.imgur.com/IyB6mIb.png"/> | MTVUutiset.fi |

<h2>Local channels</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | Nopola News | [>](https://virta2.nopolanews.fi:8443/live/smil:Stream1.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/gOj8J6O.png"/> | NopolaNews.fi |
| 0   | När-TV Ⓢ | [>](https://streaming.nartv.fi/live/ngrp:NAR_TV.stream_all/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Ht5yePq.png"/> | NarTV.fi |
| 0   | Sundom TV Ⓨ | [>](https://www.youtube.com/@SundomTV/live) | <img height="20" src="https://i.imgur.com/WgwR7nJ.png"/> | SundomTV.fi |
| 0   | Wör TV Ⓨ | [>](https://www.youtube.com/@wor-tvr.f.4461/live) | <img height="20" src="https://i.imgur.com/P9O1jo0.png"/> | WorTV.fi |

<h2>Internet</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | YleX Studio Live | [>](https://ylestudiolive.akamaized.net/hls/live/2007826/ylestudiolive-YleX/master.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/YleX.svg/450px-YleX.svg.png"/> | YleX.fi |
| 0   | Järviradio TV | [>](https://streamer.radiotaajuus.fi/memfs/47f113bf-04ea-493b-a9d4-52945fd9db31.m3u8) | <img height="20" src="https://jarviradio.fi/jrtv2/wp-content/uploads/2022/01/jrtv1.jpg"/> | JRTVJarviradio.fi |
