<h1>News (ES)</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Euronews Español Ⓨ | [>](https://www.youtube.com/euronewses/live) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Euronews_2022.svg/640px-Euronews_2022.svg.png"/> | EuronewsSpanish.fr |
| 2   | France 24 Español Ⓨ | [>](https://www.youtube.com/c/FRANCE24Espanol/live) | <img height="20" src="https://i.imgur.com/61MSiq9.png"/> | France24Espanol.fr |
| 3   | DW Español Ⓢ  | [>](https://dwamdstream104.akamaized.net/hls/live/2015530/dwstream104/stream04/streamPlaylist.m3u8) | <img height="20" src="https://i.imgur.com/A1xzjOI.png"/> | DWEspanol.de |
| 4   | CGTN Español    | [>](https://news.cgtn.com/resource/live/espanol/cgtn-e.m3u8) | <img height="20" src="https://i.imgur.com/fMsJYzl.png"/> | CGTNSpanish.cn |
| 5   | RT Español Ⓖ  | [>](https://rt-esp.rttv.com/dvr/rtesp/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Russia-today-logo.svg/512px-Russia-today-logo.svg.png"/> | RTenEspanol.ru |
| 6   | RTVE 24H | [>](https://ztnr.rtve.es/ztnr/1694255.m3u8) | <img height="20" src="https://i.imgur.com/WTDKOoM.png"/> | rtve.es |
