<h1>Peru</h1>

| #    | Channel        | Link  | Logo | EPG id |
|:----:|:--------------:|:-----:|:----:|:------:|
| 5 | Panamericana TV | [>](https://cdnhd.iblups.com/hls/ptv2.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/2/26/Panamericana_tv_2009.png"/> | PanamericanaTV.pe |
| 15 | ATV+ Noticias   | [>](https://dysmuyxh5vstv.cloudfront.net/hls/atv2.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/f/f4/Atv_noticias_logo.png"/> | ATVPlus.pe |
| 62 | Karibeña TV   | [>](https://cu.onliv3.com/livevd/user1.m3u8) | <img height="20" src="https://i.pinimg.com/280x280_RS/11/85/b6/1185b667fe3f80d7072359d7ce7ce52d.jpg"/> | Karibena.pe |
| 63 | Top Latino TV   | [>](https://5cefcbf58ba2e.streamlock.net:543/tltvweb/latintv.stream/playlist.m3u8) | <img height="20" src="https://static.mytuner.mobi/media/tvos_radios/fTmfsKeREm.png"/> | TopLatinoTV.pe |
