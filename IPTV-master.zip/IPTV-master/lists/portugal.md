<h1>Portugal</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | RTP1 | [>](https://streaming-live.rtp.pt/liverepeater/smil:rtp1HD.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/RTP1_-_Logo_2016.svg/640px-RTP1_-_Logo_2016.svg.png"/> | RTP1.pt |
| 2   | RTP2 Ⓖ | [>](https://streaming-live.rtp.pt/liverepeater/rtp2HD.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/en/4/4d/Rtp2_2016_logo.png"/> | RTP2.pt |
| 3   | SIC | [>](https://d1zx6l1dn8vaj5.cloudfront.net/out/v1/b89cc37caa6d418eb423cf092a2ef970/index.m3u8) | <img height="20" src="https://i.imgur.com/SPMqiDG.png"/> | SIC.pt |
| 4   | TVI | [x]() | <img height="20" src="https://upload.wikimedia.org/wikipedia/en/6/63/TVI_logo_2017.png"/> | TVI.pt |
| 5   | RTP Açores | [>](https://streaming-live.rtp.pt/liverepeater/smil:rtpacoresHD.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/aa/RTP_A%C3%A7ores_%282016%29.svg/640px-RTP_A%C3%A7ores_%282016%29.svg.png"/> | RTPAcores.pt |
| 5   | RTP Madeira Ⓢ | [>](https://streaming-live.rtp.pt/liverepeater/smil:rtpmadeira.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/en/a/ac/RTP_Madeira_2016.png"/> | RTPMadeira.pt |
| 6   | RTP3 | [>](https://streaming-live.rtp.pt/livetvhlsDVR/rtpnHDdvr.smil/playlist.m3u8?DVR=) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/b/b9/Rtp3.png"/> | RTP3.pt |
| 7   | RTP Memória | [x]() | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/7/79/RtpMemoria_positivo_horiz_RGB.png"/> | RTPMemoria.pt |
| 1   | Porto Canal Ⓢ | [>](https://streamer-a01.videos.sapo.pt/live/portocanal/playlist.m3u8) | <img height="20" src="https://i.imgur.com/wsyvP2H.png"/> | PortoCanal.pt |
| 2   | ADtv Ⓢ         | [>](https://playout172.livextend.cloud/liveiframe/_definst_/ngrp:liveartvabr_abr/playlist.m3u8) | <img height="20" src="https://i.imgur.com/FvlcU3z.png"/> |
| 3   | CNN Portugal    | [>](https://sktv-forwarders.7m.pl/get.php?x=CNN_Portugal) | <img height="20" src="https://i.imgur.com/NYH39xs.png"/> | CNNPortugal.pt |
| 4   | Euronews em Português Ⓨ| [>](https://www.youtube.com/euronewspt/live) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Euronews_2022.svg/640px-Euronews_2022.svg.png"/> | EuronewsPortuguese.fr |
