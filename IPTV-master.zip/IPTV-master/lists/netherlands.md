<h1>Netherlands</h1>

<h2>National</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | NPO 1 Ⓖ   | [>](http://resolver.streaming.api.nos.nl/livestream?url=/live/npo/tvlive/npo1/npo1.isml/.m3u8) | <img height="20" src="https://i.imgur.com/pUBy4Pb.png"/> | NPO1.nl |
| 2   | NPO 2 Ⓖ   | [>](http://resolver.streaming.api.nos.nl/livestream?url=/live/npo/tvlive/npo2/npo2.isml/.m3u8) | <img height="20" src="https://i.imgur.com/Vl2G1H3.png"/> | NPO2.nl |
| 3   | NPO 3 Ⓖ   | [>](http://resolver.streaming.api.nos.nl/livestream?url=/live/npo/tvlive/npo3/npo3.isml/.m3u8) | <img height="20" src="https://i.imgur.com/dVB4Pqc.png"/> | NPO3.nl |
| 4   | RTL 4     | [x]() | <img height="20" src="https://i.imgur.com/qzvUqSX.png"/> | RTL4.nl |
| 5   | RTL 5     | [x]() | <img height="20" src="https://i.imgur.com/paBpoKB.png"/> | RTL5.nl |
| 7   | RTL 7     | [x]() | <img height="20" src="https://i.imgur.com/MxWqvuQ.png"/> | RTL7.nl |
| 8   | RTL 8     | [x]() | <img height="20" src="https://i.imgur.com/gnKZbqd.png"/> | RTL8.nl |

<h2>Regional</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Omrop Fryslân      | [>](https://d3pvma9xb2775h.cloudfront.net/live/omropfryslan/f8f68bd5/playlist.m3u8) | <img height="20" src="https://i.imgur.com/0VKJLAK.png"/> | OmropFryslanTV.nl |
| 2   | RTV Noord          | [>](https://media.rtvnoord.nl/live/rtvnoord/tv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/pO5Mexa.png"/> | RTVNoord.nl |
| 3   | RTV Drenthe        | [>](https://cdn.rtvdrenthe.nl/live/rtvdrenthe/tv/1080p/prog_index.m3u8) | <img height="20" src="https://i.imgur.com/GaGqM4z.png"/> | RTVDrenthe.nl |
| 4   | RTV Oost           | [>](https://d34cg2bnc08ruf.cloudfront.net/live/rtvoost/tv/index.m3u8) | <img height="20" src="https://i.imgur.com/8ropV29.png"/> | RTVOost.nl |
| 5   | Omroep Gelderland  | [>](https://d2od87akyl46nm.cloudfront.net/live/omroepgelderland/tvgelderland-hls/index.m3u8) | <img height="20" src="https://i.imgur.com/TPlyvUQ.png"/> | OmroepGelderlandTV.nl |
| 6   | RTV Utrecht        | [>](http://media.rtvutrecht.nl/live/rtvutrecht/rtvutrecht/index.m3u8) | <img height="20" src="https://i.imgur.com/c0I24N6.png"/> | RTVUtrecht.nl |
| 7   | Omroep Flevoland Ⓢ | [>](https://d5ms27yy6exnf.cloudfront.net/live/omroepflevoland/tv/index.m3u8) | <img height="20" src="https://i.imgur.com/d1CmTcI.png"/> | OmroepFlevolandTV.nl |
| 8   | NH Nieuws          | [>](https://rrr.sz.xlcdn.com/?account=nhnieuws&file=live&type=live&service=wowza&protocol=https&output=playlist.m3u8) | <img height="20" src="https://i.imgur.com/SQPVOwn.png"/> |
| 9   | RTV Rijnmond       | [>](https://dcur8bjarl5c2.cloudfront.net/live/rijnmond/tv/index.m3u8) | <img height="20" src="https://i.imgur.com/TNhUVEm.png"/> | RTVRijnmond.nl |
| 10  | Omroep West        | [>](https://d1axml5ozykh3g.cloudfront.net/live/omroepwest/tv/index.m3u8) | <img height="20" src="https://i.imgur.com/aax1HPH.png"/> | OmroepWestTV.nl |
| 11  | Omroep Zeeland     | [>](http://d3isaxd2t6q8zm.cloudfront.net/live/omroepzeeland/tv/index.m3u8) | <img height="20" src="https://i.imgur.com/8aLDyUI.png"/> | OmroepZeelandTV.nl |
| 12  | Omroep Brabant     | [>](http://d3slqp9xhts6qb.cloudfront.net/live/omroepbrabant/tv/index.m3u8) | <img height="20" src="https://i.imgur.com/Jv7IjHJ.png"/> | OmroepBrabantTV.nl |
| 13  | L1 Ⓢ               | [>](http://d34pj260kw1xmk.cloudfront.net/live/l1/tv/index.m3u8) | <img height="20" src="https://i.imgur.com/Jyhn1iP.png"/> | L1TV.nl |
