<h1>San Marino</h1>

<h2>DVB-T</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 73  | San Marino Rtv | [>](https://d2hrvno5bw6tg2.cloudfront.net/smrtv-ch01/_definst_/smil:ch-01.smil/chunklist_b2192000_slita.m3u8) | <img height="20" src="https://i.imgur.com/lJpOlLv.png"/> | SanMarinoRTV.sm |
| 93  | San Marino Rtv Sport | [>](https://d2hrvno5bw6tg2.cloudfront.net/smrtv-ch02/_definst_/smil:ch-02.smil/chunklist_b1692000_slita.m3u8) | <img height="20" src="https://i.imgur.com/PGm944g.png"/> | SanMarinoRTVSport.sm |

<h2>Invalid</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
