<h1>Lithuania</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | LRT TV | [>](https://stream-syncwords.lrt.lt/out/v1/channel-group-lrt-portal-prod-01/channel-lrt-portal-prod-01/endpoint-lrt-portal-prod-01/index.m3u8) | <img height="20" src="https://i.imgur.com/FL2ZuGC.png"/> | LRTTV.lt |
| 3   | LRT Lituanica | [>](https://stream-live.lrt.lt/lituanica/master.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d2/LRT_Lituanica_Logo_2022.svg/640px-LRT_Lituanica_Logo_2022.svg.png"/> | LRTLituanica.lt |
| 9   | Lietuvos Rytas TV | [>](https://live.lietuvosryto.tv/live/hls/eteris.m3u8) | <img height="20" src="https://i.imgur.com/5wpxVI0.png"/> | LietuvosRytasTV.lt |
| 10  | Delfi TV | [>](https://s1.dcdn.lt/live/televizija/playlist.m3u8) | <img height="20" src="https://i.imgur.com/IFoHP5M.png"/> | DelfiTV.lt |

<h2>Invalid</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 2   | LRT Plius | [x](https://www.tvkaista.net/stream-forwarder/get.php?x=LRTPlius) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/61/LRT_Plius_Logo_2022.svg/512px-LRT_Plius_Logo_2022.svg.png"/> | LRTPlius.lt |
| 3   | TV3 Ⓢ | [x](http://88.216.83.245/tv3/index.m3u8) | <img height="20" src="https://i.imgur.com/7nipq0y.png"/> | TV3Lithuania.lt |
| 6   | TV6 Ⓢ | [x](http://88.216.83.245/tv6/index.m3u8) | <img height="20" src="https://i.imgur.com/oC0jiFW.png"/> | TV6Lithuania.lt |
| 8   | TV8 Ⓢ | [x](http://88.216.83.245/tv8/index.m3u8) | <img height="20" src="https://i.imgur.com/9g3wknl.png"/> | TV8Lithuania.lt |
| 9   | LNK | [x](https://www.tvkaista.net/stream-forwarder/get.php?x=LNK) | <img height="20" src="https://i.imgur.com/arCZ56g.png"/> | LNK.lt |
| 10  | BTV | [x](https://www.tvkaista.net/stream-forwarder/get.php?x=BTV) | <img height="20" src="https://i.imgur.com/AeplGsP.png"/> | BTV.lt |
| 11  | 2TV | [x](https://www.tvkaista.net/stream-forwarder/get.php?x=2TV) | <img height="20" src="https://i.imgur.com/sZUIhGc.png"/> | 2TV.lt |
| 12  | Info TV | [x](https://www.tvkaista.net/stream-forwarder/get.php?x=InfoTV) | <img height="20" src="https://i.imgur.com/EjQtIpM.png"/> | InfoTV.lt |
| 13  | TV1 | [x](https://www.tvkaista.net/stream-forwarder/get.php?x=TV1) | <img height="20" src="https://i.imgur.com/KLWDcFy.png"/> | TV1.lt |
| 14  | TVP Wilno | [x](https://www.tvkaista.net/stream-forwarder/get.php?x=TVPWilno) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/TVP_Wilno_%282019%29.svg/640px-TVP_Wilno_%282019%29.svg.png"/> | TVPWilno.pl |